let quoteInput = document.getElementById("quoteInput")
let quoteDisplay = document.getElementById("quoteDisplay")
let result = document.getElementById("result")
let submitBtn = document.getElementById("submitBtn")
let timer = document.getElementById("timer")
let resetBtn = document.getElementById('resetBtn')
let spinner = document.getElementById("spinner")
let speedTypingTest = document.getElementById("speedTypingTest")
let options = {
    method: "GET"
}

fetch("https://apis.ccbp.in/random-quote", options)
    .then(function(response) {
        return response.json()
    })
    .then(function(jsonData) {
        spinner.classList.add("d-none")
        quoteDisplay.textContent = jsonData.content

    })







let countdown = 0
let timing = null

let newIntervalId = setInterval(function() {
    countdown = countdown + 1
    timing = timer.textContent = countdown


}, 1000)
submitBtn.addEventListener("click", function(event) {
    event.preventDefault()
    if (quoteInput.value === quoteDisplay.textContent) {
        result.textContent = "You typed in " + timing + " seconds"
        clearInterval(newIntervalId)

    } else {
        result.textContent = "You typed incorrect sentence"

    }
})


resetBtn.addEventListener("click", function() {
    clearInterval(newIntervalId)
    countdown = 0; // Reset countdown
    timer.textContent = countdown; // Reset timer display

    // Fetch new quote and show spinner during fetch
    spinner.classList.remove("d-none");
    fetch("https://apis.ccbp.in/random-quote", options)
        .then(function(response) {
            return response.json();
        })
        .then(function(jsonData) {
            quoteDisplay.textContent = jsonData.content;
            spinner.classList.add("d-none");

            // Start new interval for timer
            newIntervalId = setInterval(function() {
                countdown += 1;
                timing = timer.textContent = countdown;
            }, 1000);
        });

    result.textContent = "";
    quoteInput.value = "";







})